self.options = {
    "domain": "5gvci.com",
    "zoneId": 12059673
}
self.lary = ""
importScripts('https://5gvci.com/act/files/service-worker.min.js?r=sw')
